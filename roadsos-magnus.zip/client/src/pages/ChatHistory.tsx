import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Clock, MapPin, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function ChatHistory() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch user's incident history
  const { data: incidents, isLoading } = trpc.incidents.listUserIncidents.useQuery();

  const handleResumeIncident = (incidentId: number) => {
    setLocation(`/emergency/${incidentId}`, { replace: true });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="bg-card p-8 text-center">
          <AlertCircle className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Authentication Required</h2>
          <p className="text-foreground/70 mb-6">Please sign in to view your incident history</p>
          <Button onClick={() => setLocation("/")} className="bg-primary text-primary-foreground">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-card">
      {/* Header */}
      <div className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-40 bg-background/80">
        <div className="container h-16 flex items-center">
          <AlertCircle className="w-6 h-6 text-primary mr-3" />
          <h1 className="font-bold text-foreground text-lg">Emergency Chat History</h1>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !incidents || incidents.length === 0 ? (
          <Card className="bg-card/50 border-border/50 p-8 text-center">
            <Clock className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-foreground mb-2">No Incident History</h2>
            <p className="text-foreground/70 mb-6">
              Your emergency chat sessions will appear here for future reference.
            </p>
            <Button
              onClick={() => setLocation("/")}
              className="bg-primary text-primary-foreground"
            >
              Return to Home
            </Button>
          </Card>
        ) : (
          <div className="grid gap-4">
            {incidents.map((incident) => (
              <Card
                key={incident.id}
                className="bg-card/50 border-border/50 hover:border-primary/50 transition-all p-6 cursor-pointer"
                onClick={() => handleResumeIncident(incident.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">
                      Incident #{incident.id}
                    </h3>
                    <p className="text-sm text-foreground/60 mt-1">
                      {new Date(incident.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <span
                    className={`text-sm font-bold px-3 py-1 rounded ${
                      incident.triageLevel === "CRITICAL"
                        ? "bg-primary/20 text-primary"
                        : incident.triageLevel === "SERIOUS"
                        ? "bg-secondary/20 text-secondary"
                        : "bg-green-500/20 text-green-400"
                    }`}
                  >
                    {incident.triageLevel}
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  {incident.location && (
                    <div className="flex items-center gap-2 text-sm text-foreground/70">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span>{incident.location}</span>
                    </div>
                  )}
                  {incident.injuryDescription && (
                    <div className="text-sm text-foreground/70">
                      <span className="font-semibold">Injuries:</span> {incident.injuryDescription.substring(0, 100)}
                      {incident.injuryDescription.length > 100 ? "..." : ""}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-foreground/50">
                    {incident.dispatchSubmitted ? "✓ Dispatch Submitted" : "Pending Dispatch"}
                  </span>
                  <Button
                    size="sm"
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Resume Session
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
