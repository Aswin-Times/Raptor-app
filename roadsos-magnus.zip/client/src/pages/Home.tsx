import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, MapPin, Phone, Zap, MessageCircle, Shield, Clock } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const createIncident = trpc.incidents.create.useMutation();
  const [isLoading, setIsLoading] = useState(false);

  const handleGetHelpNow = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    setIsLoading(true);
    try {
      const result = await createIncident.mutateAsync({
        triageLevel: "CRITICAL",
        language: "en",
      });
      setLocation(`/emergency/${result.id}`, { replace: true });
    } catch (error) {
      console.error("Failed to create incident:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignIn = () => {
    window.location.href = getLoginUrl();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-card">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-8 h-8 text-primary" />
            <span className="text-xl font-bold text-foreground">RoadSOS Magnus</span>
          </div>
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setLocation("/history")}
                  className="text-foreground/70 hover:text-foreground"
                >
                  History
                </Button>
                <span className="text-sm text-foreground/80">{user?.name || "User"}</span>
              </>
            ) : (
              <Button variant="outline" size="sm" onClick={handleSignIn}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 mb-6">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Real-time Emergency Response</span>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
              Your AI Emergency Co-Pilot
            </h1>

            <p className="text-xl text-foreground/80 mb-8 leading-relaxed">
              RoadSOS Magnus guides you through road accidents with expert triage, real-time first aid instructions, and instant emergency dispatch coordination. Every second counts.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg h-14 px-8 rounded-lg shadow-lg hover:shadow-xl transition-all"
                onClick={handleGetHelpNow}
                disabled={isLoading}
              >
                {isLoading ? "Starting..." : "Get Help Now"}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary/50 text-foreground hover:bg-primary/10 font-bold text-lg h-14 px-8 rounded-lg"
              >
                Learn More
              </Button>
            </div>

            {/* Emergency Numbers */}
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="bg-card/50 backdrop-blur border border-border/50 rounded-lg p-3">
                <div className="text-2xl font-bold text-primary">112</div>
                <div className="text-xs text-foreground/70">Universal</div>
              </div>
              <div className="bg-card/50 backdrop-blur border border-border/50 rounded-lg p-3">
                <div className="text-2xl font-bold text-primary">108</div>
                <div className="text-xs text-foreground/70">Ambulance</div>
              </div>
              <div className="bg-card/50 backdrop-blur border border-border/50 rounded-lg p-3">
                <div className="text-2xl font-bold text-primary">100</div>
                <div className="text-xs text-foreground/70">Police</div>
              </div>
            </div>
          </div>
        </div>

        {/* Animated background elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl opacity-20 -z-10 animate-pulse" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl opacity-20 -z-10 animate-pulse" />
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-32 border-t border-border/50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Advanced Emergency Response Features
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Powered by Gemma 4 AI, designed for real-world emergencies
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <MessageCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">AI Triage Assessment</h3>
              <p className="text-foreground/70">
                Real-time injury assessment with CRITICAL, SERIOUS, and MINOR classifications
              </p>
            </Card>

            {/* Feature 2 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">First Aid Guidance</h3>
              <p className="text-foreground/70">
                Step-by-step emergency first aid instructions tailored to reported injuries
              </p>
            </Card>

            {/* Feature 3 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <Phone className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">Dispatch Coordination</h3>
              <p className="text-foreground/70">
                Instant access to emergency services with location-based contact recommendations
              </p>
            </Card>

            {/* Feature 4 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">Location Mapping</h3>
              <p className="text-foreground/70">
                Interactive map integration for precise accident location capture and sharing
              </p>
            </Card>

            {/* Feature 5 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">Voice-to-Text Input</h3>
              <p className="text-foreground/70">
                Hands-free emergency reporting with automatic speech transcription
              </p>
            </Card>

            {/* Feature 6 */}
            <Card className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-all p-6">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">Incident Logging</h3>
              <p className="text-foreground/70">
                Complete chat history and incident reports saved for review and follow-up
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 border-t border-border/50 bg-card/30">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Ready to Save Lives?
          </h2>
          <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto">
            In an emergency, every second matters. RoadSOS Magnus is here to guide you through the crisis with expert AI support.
          </p>
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg h-14 px-8 rounded-lg shadow-lg hover:shadow-xl transition-all"
            onClick={handleGetHelpNow}
            disabled={isLoading}
          >
            {isLoading ? "Starting..." : "Get Help Now"}
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 bg-background/50">
        <div className="container text-center text-foreground/60 text-sm">
          <p>RoadSOS Magnus — AI-Powered Emergency Response System</p>
          <p className="mt-2">Always call 112 in life-threatening emergencies</p>
        </div>
      </footer>
    </div>
  );
}
