import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { AlertCircle, Send, Phone, MapPin, Mic, Loader2, History, Square } from "lucide-react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { Streamdown } from "streamdown";

export default function EmergencyChat() {
  const { incidentId } = useParams<{ incidentId: string }>();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const [messages, setMessages] = useState<Array<{ role: string; content: any }>>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);

  const id = parseInt(incidentId || "0");

  // Fetch incident and chat history
  const { data: incident } = trpc.incidents.getById.useQuery({ id }, { enabled: !!id });
  const { data: chatHistory } = trpc.chat.getHistory.useQuery({ incidentId: id }, { enabled: !!id });

  // Mutations
  const sendMessage = trpc.ai.chat.useMutation();
  const addChatMessage = trpc.chat.addMessage.useMutation();

  // Load chat history on mount
  useEffect(() => {
    if (chatHistory && chatHistory.length > 0) {
      setMessages(
        chatHistory.map((msg) => ({
          role: msg.role,
          content: msg.content,
        }))
      );
    } else if (messages.length === 0) {
      // Initial greeting
      const greeting =
        "I am ROADSOS MAGNUS, your AI emergency co-pilot. I'm here to guide you through this crisis. Tell me what happened and describe any injuries.";
      setMessages([{ role: "assistant", content: greeting }]);
    }
  }, [chatHistory]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");

    // Add user message to UI
    const newMessages = [...messages, { role: "user", content: userMessage }];
    setMessages(newMessages);

    setIsLoading(true);
    try {
      // Save user message to DB
      await addChatMessage.mutateAsync({
        incidentId: id,
        role: "user",
        content: userMessage,
      });

      // Get AI response
      const response = await sendMessage.mutateAsync({
        incidentId: id,
        message: userMessage,
      });

      // Add assistant message
      const assistantMessage = typeof response.response === 'string' ? response.response : JSON.stringify(response.response);
      setMessages((prev) => [...prev, { role: "assistant", content: assistantMessage }]);

      // Save assistant message to DB
      await addChatMessage.mutateAsync({
        incidentId: id,
        role: "assistant",
        content: assistantMessage,
      });
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      setRecordingTime(0);

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        
        // Upload audio and transcribe
        try {
          setInput("🎤 Transcribing your voice message...");
          
          // Create FormData for audio upload
          const formData = new FormData();
          formData.append("audio", audioBlob, "recording.webm");
          
          // Send to backend for transcription
          const response = await fetch("/api/trpc/system.transcribeAudio", {
            method: "POST",
            body: formData,
          });

          if (response.ok) {
            const data = await response.json();
            const transcribedText = data.result?.text || "Unable to transcribe";
            setInput(transcribedText);
          } else {
            setInput("Failed to transcribe audio. Please try again.");
          }
        } catch (error) {
          console.error("Transcription error:", error);
          setInput("Error transcribing audio. Please try again.");
        }
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Start recording timer
      recordingTimerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (error) {
      console.error("Failed to start recording:", error);
      alert("Unable to access microphone. Please check permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      
      // Stop all audio tracks
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="bg-card p-8 text-center">
          <AlertCircle className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Authentication Required</h2>
          <p className="text-foreground/70 mb-6">Please sign in to access emergency chat</p>
          <Button onClick={() => setLocation("/", { replace: true })} className="bg-primary text-primary-foreground">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-card flex flex-col">
      {/* Header */}
      <div className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-40 bg-background/80">
        <div className="container h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-6 h-6 text-primary animate-pulse" />
            <div>
              <h1 className="font-bold text-foreground">RoadSOS Magnus Emergency Chat</h1>
              <p className="text-xs text-foreground/60">Incident #{id}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowHistory(!showHistory)}
            className="text-foreground/70 hover:text-foreground"
          >
            <History className="w-4 h-4 mr-2" />
            History
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-2xl rounded-lg p-4 ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-none"
                      : "bg-card border border-border/50 text-foreground rounded-bl-none"
                  }`}
                >
                  {msg.role === "assistant" ? (
                    <Streamdown>{msg.content}</Streamdown>
                  ) : (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-card border border-border/50 rounded-lg p-4 rounded-bl-none">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-border/50 p-4 bg-background/50 backdrop-blur">
            {isRecording && (
              <div className="mb-3 flex items-center gap-2 px-3 py-2 bg-primary/20 border border-primary/50 rounded-lg">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                <span className="text-sm text-primary font-medium">Recording: {formatTime(recordingTime)}</span>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                placeholder={isRecording ? "Recording in progress..." : "Describe your situation or injuries..."}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && !isRecording) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                disabled={isLoading || isRecording}
                className="flex-1 bg-input border-border/50 text-foreground placeholder:text-foreground/50"
              />
              <Button
                size="icon"
                variant={isRecording ? "destructive" : "outline"}
                onClick={isRecording ? stopRecording : startRecording}
                className="text-foreground"
                title={isRecording ? "Stop recording" : "Start voice input"}
              >
                {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
              <Button
                size="icon"
                onClick={handleSendMessage}
                disabled={isLoading || !input.trim() || isRecording}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-foreground/50 mt-2">
              {isRecording 
                ? "Recording... Click stop button to finish" 
                : "Press Enter to send or use voice input"}
            </p>
          </div>
        </div>

        {/* Sidebar - Emergency Services & Location */}
        <div className="w-80 border-l border-border/50 bg-card/30 overflow-y-auto hidden lg:flex flex-col">
          <div className="p-4 border-b border-border/50">
            <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
              <Phone className="w-4 h-4 text-primary" />
              Emergency Services
            </h3>
            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start text-left h-auto py-2 border-primary/30 hover:bg-primary/10"
                onClick={() => window.location.href = "tel:112"}
              >
                <div>
                  <div className="font-bold text-primary">112</div>
                  <div className="text-xs text-foreground/70">Universal Emergency</div>
                </div>
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start text-left h-auto py-2 border-primary/30 hover:bg-primary/10"
                onClick={() => window.location.href = "tel:108"}
              >
                <div>
                  <div className="font-bold text-primary">108</div>
                  <div className="text-xs text-foreground/70">Ambulance</div>
                </div>
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start text-left h-auto py-2 border-primary/30 hover:bg-primary/10"
                onClick={() => window.location.href = "tel:100"}
              >
                <div>
                  <div className="font-bold text-primary">100</div>
                  <div className="text-xs text-foreground/70">Police</div>
                </div>
              </Button>
            </div>
          </div>

          <div className="p-4 border-b border-border/50">
            <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              Location
            </h3>
            <Card className="bg-background/50 border-border/50 p-3 text-center">
              <p className="text-sm text-foreground/70">
                {incident?.location || "Location not set"}
              </p>
              <p className="text-xs text-foreground/50 mt-1">
                {incident?.latitude && incident?.longitude
                  ? `${incident.latitude}, ${incident.longitude}`
                  : "GPS coordinates pending"}
              </p>
            </Card>
          </div>

          <div className="p-4">
            <h3 className="font-bold text-foreground mb-4">Incident Status</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground/70">Triage Level:</span>
                <span
                  className={`text-sm font-bold px-2 py-1 rounded ${
                    incident?.triageLevel === "CRITICAL"
                      ? "bg-primary/20 text-primary"
                      : incident?.triageLevel === "SERIOUS"
                      ? "bg-secondary/20 text-secondary"
                      : "bg-green-500/20 text-green-400"
                  }`}
                >
                  {incident?.triageLevel || "PENDING"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground/70">Dispatch:</span>
                <span className="text-sm text-foreground/50">
                  {incident?.dispatchSubmitted ? "Submitted" : "Pending"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
